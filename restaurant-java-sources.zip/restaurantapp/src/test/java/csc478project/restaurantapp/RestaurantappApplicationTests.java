package csc478project.restaurantapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
class RestaurantappApplicationTests {

	@PersistenceContext
	private EntityManager entityManager;

	@Test
	void contextLoads() {
	}

	@Test
	@Transactional
	void persistsAndReadsRestaurantFromPostgres() {
		Restaurant restaurant = new Restaurant("Test Restaurant", "123 Test Street");

		entityManager.persist(restaurant);
		entityManager.flush();

		Restaurant savedRestaurant = entityManager.find(Restaurant.class, restaurant.getId());

		assertNotNull(restaurant.getId());
		assertNotNull(savedRestaurant);
		assertEquals("Test Restaurant", savedRestaurant.getName());
		assertEquals("123 Test Street", savedRestaurant.getAddress());
	}

}
