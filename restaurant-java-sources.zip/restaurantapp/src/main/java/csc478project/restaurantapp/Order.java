package csc478project.restaurantapp;

public class Order {
    
}
