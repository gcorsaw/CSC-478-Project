package csc478project.restaurantapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantappApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantappApplication.class, args);
	}

}
