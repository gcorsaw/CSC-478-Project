package csc478project.restaurantapp;

public class RestaurantTableReposit {
    
}
